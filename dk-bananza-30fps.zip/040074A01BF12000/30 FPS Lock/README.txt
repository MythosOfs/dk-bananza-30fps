Donkey Kong Bananza - 30 FPS Lock (Orchid/Eden ExeFS-Patch)

Was: Das Spiel fordert immer Swap-Intervall 2 an -> stabile 30 fps bei normalem Tempo
(main-NSO 0x204ac4: csel w10,w8,w9,lt -> mov w10,#2).
Nur fuer Build-ID E25C90C1C136638885659FD55BF8A03B3403489D (main), bei anderer Spielversion wirkungslos.

Installieren: Rechtsklick aufs Spiel -> Eigenschaften -> Add-Ons -> "Import Mod from ZIP",
oder den Ordner 040074A01BF12000 aus dem Zip nach ~/.local/share/eden/load/ ziehen.
Abschalten: Haken bei "30 FPS Lock" in den Add-Ons entfernen.
